export class IntegrationDto {
  integration: string;
  number: string;
  token: string;
}
