export class SqsDto {
  enabled: boolean;
  events?: string[];
}
